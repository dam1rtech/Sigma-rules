#!/usr/bin/env python3
"""Validate that every Sigma rule parses and has the required fields.

Run from the repo root:  python3 tests/validate.py
Exit code is non-zero if any rule is invalid, so it can be used in CI.
"""
import glob
import sys

try:
    import yaml
except ImportError:
    sys.exit("PyYAML is required:  pip install pyyaml")

REQUIRED_FIELDS = ["title", "id", "logsource", "detection", "level"]
RULE_GLOB = "rules/**/*.yml"


def validate_rule(path: str) -> list[str]:
    """Return a list of problems for a single rule file (empty == valid)."""
    problems: list[str] = []
    try:
        with open(path, encoding="utf-8") as fh:
            rule = yaml.safe_load(fh)
    except yaml.YAMLError as exc:
        return [f"invalid YAML: {exc}"]

    if not isinstance(rule, dict):
        return ["top-level document is not a mapping"]

    for field in REQUIRED_FIELDS:
        if field not in rule:
            problems.append(f"missing required field: '{field}'")

    detection = rule.get("detection", {})
    if isinstance(detection, dict) and "condition" not in detection:
        problems.append("detection block has no 'condition'")

    tags = rule.get("tags", [])
    if not any(str(t).startswith("attack.t") for t in tags):
        problems.append("no MITRE ATT&CK technique tag (attack.tXXXX)")

    return problems


def main() -> int:
    files = sorted(glob.glob(RULE_GLOB, recursive=True))
    if not files:
        print("No rule files found.")
        return 1

    failed = 0
    for path in files:
        problems = validate_rule(path)
        if problems:
            failed += 1
            print(f"FAIL  {path}")
            for p in problems:
                print(f"        - {p}")
        else:
            print(f"OK    {path}")

    total = len(files)
    print(f"\n{total - failed}/{total} rules valid")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
